# ANEES VIDEO DOWNLOADER — Android project

A native Kotlin Android starter app with a black-and-gold luxury UI. It accepts **direct media file URLs** (for example, an MP4 URL hosted by a site that permits downloading), checks that the URL appears to resolve to media, and queues the file using Android's DownloadManager.

## Important platform limitation
This app does not extract media streams from YouTube, Instagram, TikTok, Facebook, or other platform pages, and it does not bypass DRM, login, paywalls, or download restrictions. Many platforms prohibit downloading through third-party apps. Use each platform's official download/offline/creator tools or an authorized direct media URL. A platform page URL is not a direct video file URL.

## Requirements
- Android Studio (current stable)
- Android SDK Platform 35
- JDK 17
- Internet access for Gradle dependency/plugin resolution

## Build the APK
1. Unzip this project.
2. Open the `ANEES_VIDEO_DOWNLOADER` folder in Android Studio.
3. Allow Gradle sync to finish. Install Android SDK 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When complete, click **locate** in the build notification.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager/browser.

For a signed release APK: **Build → Generate Signed Bundle / APK → APK**, create or select a keystore, choose the release build variant, and finish the wizard. Keep your keystore and passwords private and backed up.

## Current implementation
- Black + gold English interface
- Paste link from clipboard
- HTTP/HTTPS URL validation
- Background direct-media link check
- Download queue via Android DownloadManager
- Local Download History (latest 30 queued requests, stored on-device)
- Completion notification from Android
- Saves to `Downloads/ANEES/`
- No broad storage permission is requested

## Current limitations / next development steps
- The link checker is intentionally conservative; some hosts block requests or require cookies/headers, so a valid authorized link may fail verification.
- This starter does not provide an in-app media library, custom pause/resume controls, format conversion, or platform-specific integrations.
- Android DownloadManager handles the transfer and system notification. Download history can be viewed in the device's Downloads app.
- Before publishing, add a privacy policy, app icon, tested error states, accessibility labels, and verify compliance with Google Play and each source platform's terms.
