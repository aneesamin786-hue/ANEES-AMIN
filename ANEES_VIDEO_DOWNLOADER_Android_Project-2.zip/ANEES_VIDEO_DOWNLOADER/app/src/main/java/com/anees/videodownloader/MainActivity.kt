package com.anees.videodownloader

import android.app.Activity
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = 0xFF090909.toInt()
    private val panel = 0xFF171717.toInt()
    private val gold = 0xFFD4AF37.toInt()
    private val white = 0xFFF5F1E6.toInt()
    private val muted = 0xFFB7B1A2.toInt()
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var analyzeButton: Button
    private lateinit var downloadButton: Button
    private lateinit var historyContainer: LinearLayout
    private var checkedUrl: String? = null
    private var suggestedName = "anees_video"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "ANEES"
            textSize = 14f
            letterSpacing = 0.35f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        page.addView(brand, matchWrap())

        val title = TextView(this).apply {
            text = "VIDEO DOWNLOADER"
            textSize = 25f
            letterSpacing = 0.06f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(4))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Save videos from direct links you are authorized to download"
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(18), dp(17), dp(18))
            setBackgroundColor(panel)
        }
        page.addView(card, LinearLayout.LayoutParams(-1, -2))

        label(card, "VIDEO URL")
        urlInput = EditText(this).apply {
            hint = "https://example.com/video.mp4"
            setHintTextColor(0xFF777777.toInt())
            setTextColor(white)
            textSize = 14f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(12), dp(13), dp(12), dp(13))
            background = roundedDrawable(0xFF242424.toInt(), 10)
        }
        card.addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))

        val paste = goldButton("PASTE LINK")
        card.addView(paste, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        paste.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                urlInput.setText(clip.getItemAt(0).coerceToText(this).toString())
            } else toast("Clipboard is empty")
        }

        analyzeButton = goldButton("CHECK VIDEO LINK")
        card.addView(analyzeButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        analyzeButton.setOnClickListener { analyzeLink() }

        downloadButton = darkButton("DOWNLOAD VIDEO")
        downloadButton.isEnabled = false
        card.addView(downloadButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        downloadButton.setOnClickListener { startDownload() }

        status = TextView(this).apply {
            text = "Ready. Paste a direct video file URL to begin."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(2), dp(17), dp(2), dp(4))
        }
        card.addView(status, matchWrap())

        val info = TextView(this).apply {
            text = "SUPPORTED LINKS\\nDirect MP4, WebM and other downloadable media URLs. Availability depends on the source server."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(24), 0, dp(10))
        }
        page.addView(info, matchWrap())

        val historyTitle = TextView(this).apply {
            text = "DOWNLOAD HISTORY"
            textSize = 13f
            letterSpacing = 0.12f
            setTextColor(gold)
            setPadding(0, dp(18), 0, dp(10))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(historyTitle, matchWrap())
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = roundedDrawable(0xFF171717.toInt(), 10)
        }
        page.addView(historyContainer, matchWrap())
        renderHistory()

        val note = TextView(this).apply {
            text = "LEGAL & PRIVACY\\nOnly download content you own or are authorized to save. This app does not bypass DRM, sign-in, paywalls or platform restrictions. YouTube and many social platforms do not expose direct downloadable media links; use their official download or creator tools where available."
            textSize = 12f
            setTextColor(0xFF8E887B.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = roundedDrawable(0xFF121212.toInt(), 10)
        }
        page.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        val footer = TextView(this).apply {
            text = "ANEES VIDEO DOWNLOADER  •  VERSION 1.0"
            textSize = 10f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        page.addView(footer, matchWrap())
    }

    private fun analyzeLink() {
        val raw = urlInput.text.toString().trim()
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            toast("Enter a valid http or https URL")
            return
        }
        checkedUrl = null
        downloadButton.isEnabled = false
        analyzeButton.isEnabled = false
        status.text = "Checking link…"
        thread {
            var result = "Could not verify this URL. The server may block link checks."
            var valid = false
            var name = "anees_video"
            try {
                val connection = URL(raw).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 9000
                connection.readTimeout = 9000
                connection.setRequestProperty("Range", "bytes=0-0")
                connection.instanceFollowRedirects = true
                connection.connect()
                val type = connection.contentType?.lowercase(Locale.ROOT) ?: ""
                val path = Uri.parse(connection.url.toString()).lastPathSegment ?: "anees_video"
                name = path.substringBefore("?").ifBlank { "anees_video" }
                valid = connection.responseCode in 200..299 &&
                    (type.startsWith("video/") || type.startsWith("audio/") ||
                     name.lowercase(Locale.ROOT).matches(Regex(".*\\.(mp4|m4v|webm|mov|mkv|mp3|m4a|aac|ogg)(\\?.*)?$")))
                result = if (valid) "Direct media link verified. Ready to download." else
                    "This does not appear to be a direct media file. Use an official download option if the platform provides one."
                connection.disconnect()
            } catch (_: Exception) { }
            runOnUiThread {
                analyzeButton.isEnabled = true
                status.text = result
                if (valid) {
                    checkedUrl = raw
                    suggestedName = name
                    downloadButton.isEnabled = true
                }
            }
        }
    }

    private fun startDownload() {
        val link = checkedUrl ?: return
        try {
            val request = DownloadManager.Request(Uri.parse(link))
                .setTitle(suggestedName)
                .setDescription("ANEES VIDEO DOWNLOADER")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ANEES/$suggestedName")
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            saveHistory(suggestedName, link)
            renderHistory()
            status.text = "Download queued. Check your notifications and Downloads/ANEES folder."
            downloadButton.isEnabled = false
            toast("Download added to queue")
        } catch (e: Exception) {
            status.text = "Could not start download: ${e.localizedMessage ?: "Unknown error"}"
        }
    }


    private fun saveHistory(fileName: String, sourceUrl: String) {
        val prefs = getSharedPreferences("anees_downloads", Context.MODE_PRIVATE)
        val previous = prefs.getString("history", "") ?: ""
        val encoded = android.util.Base64.encodeToString(
            "$fileName\\t$sourceUrl\\t${System.currentTimeMillis()}".toByteArray(Charsets.UTF_8),
            android.util.Base64.NO_WRAP
        )
        val updated = (listOf(encoded) + previous.split("\\n").filter { it.isNotBlank() })
            .distinct().take(30).joinToString("\\n")
        prefs.edit().putString("history", updated).apply()
    }

    private fun renderHistory() {
        if (!::historyContainer.isInitialized) return
        historyContainer.removeAllViews()
        val prefs = getSharedPreferences("anees_downloads", Context.MODE_PRIVATE)
        val entries = (prefs.getString("history", "") ?: "").split("\\n").filter { it.isNotBlank() }
        if (entries.isEmpty()) {
            historyContainer.addView(TextView(this).apply {
                text = "No downloads yet. Your recent download requests will appear here."
                textSize = 12f
                setTextColor(muted)
            }, matchWrap())
            return
        }
        entries.forEach { encoded ->
            val decoded = runCatching {
                String(android.util.Base64.decode(encoded, android.util.Base64.NO_WRAP), Charsets.UTF_8)
            }.getOrNull() ?: return@forEach
            val parts = decoded.split("\\t")
            val fileName = parts.getOrNull(0) ?: "Video"
            val source = parts.getOrNull(1) ?: ""
            val time = parts.getOrNull(2)?.toLongOrNull() ?: 0L
            val date = if (time > 0) java.text.DateFormat.getDateTimeInstance(
                java.text.DateFormat.SHORT, java.text.DateFormat.SHORT
            ).format(java.util.Date(time)) else "Date unavailable"
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            item.addView(TextView(this).apply {
                text = fileName
                textSize = 14f
                setTextColor(white)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }, matchWrap())
            item.addView(TextView(this).apply {
                text = "Queued • $date"
                textSize = 11f
                setTextColor(gold)
            }, matchWrap())
            item.addView(TextView(this).apply {
                text = source
                textSize = 10f
                setTextColor(muted)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }, matchWrap())
            historyContainer.addView(item, matchWrap())
            val divider = View(this).apply { setBackgroundColor(0xFF38332A.toInt()) }
            historyContainer.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun label(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(gold)
            setPadding(0, 0, 0, dp(9))
        }, matchWrap())
    }

    private fun goldButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.08f
        setTextColor(0xFF111111.toInt())
        background = roundedDrawable(gold, 10)
        isAllCaps = false
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun darkButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.08f
        setTextColor(gold)
        background = roundedDrawable(0xFF302817.toInt(), 10)
        isAllCaps = false
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun roundedDrawable(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
